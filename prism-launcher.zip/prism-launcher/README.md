# Prism Launcher

Лаунчер Minecraft с живыми шейдерными визуалами (WebGL): северное сияние, туманность, жидкий свет, туннель.

## Запуск на своём компьютере
Нужны Node.js 18+ и Java (17+ для новых версий Minecraft).

    npm install
    npm start

## Готовая сборка через GitHub Actions
1. Создай репозиторий на GitHub и загрузи туда содержимое этой папки.
2. Открой вкладку Actions и дождись сборки (или запусти вручную: Run workflow).
3. Скачай файл из Artifacts: .exe для Windows, .AppImage для Linux, .zip для macOS.

## Что внутри
- main.js: запуск игры через minecraft-launcher-core (офлайн-ник)
- renderer/app.js: шейдеры и интерфейс
- Игра хранится в папке данных приложения, отдельно от обычного .minecraft

Добавить новый визуал: допиши функцию в шейдер в renderer/app.js и кнопку в renderer/index.html.
