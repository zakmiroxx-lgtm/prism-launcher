const { app, BrowserWindow, ipcMain } = require('electron');
const path = require('path');
const { Client, Authenticator } = require('minecraft-launcher-core');

let win;
function createWindow() {
  win = new BrowserWindow({
    width: 1100, height: 680, minWidth: 820, minHeight: 560,
    backgroundColor: '#05060d', autoHideMenuBar: true, title: 'Prism Launcher', icon: path.join(__dirname, 'build', 'icon.png'),
    webPreferences: { preload: path.join(__dirname, 'preload.js') }
  });
  win.loadFile(path.join(__dirname, 'renderer', 'index.html'));
}
app.whenReady().then(createWindow);
app.on('window-all-closed', () => app.quit());

const send = (ch, data) => win && !win.isDestroyed() && win.webContents.send(ch, data);

ipcMain.handle('launch', async (_e, opts) => {
  const launcher = new Client();
  const root = path.join(app.getPath('userData'), 'game');
  const name = (opts.username || 'Player').replace(/[^\w]/g, '').slice(0, 16) || 'Player';
  const mem = Math.max(1, Math.min(32, Number(opts.ram) || 4));

  launcher.on('progress', p => send('progress', { type: p.type, task: p.task, total: p.total }));
  launcher.on('debug', m => send('log', String(m)));
  launcher.on('data', m => send('log', String(m)));
  launcher.on('close', code => send('closed', code));

  try {
    await launcher.launch({
      authorization: Authenticator.getAuth(name), // офлайн-режим
      root,
      version: { number: opts.version || '1.20.4', type: opts.vtype || 'release' },
      memory: { max: `${mem}G`, min: '1G' }
    });
    return { ok: true };
  } catch (err) {
    return { ok: false, error: String(err && err.message || err) };
  }
});

// Список всех версий берётся с серверов Mojang при каждом запуске
ipcMain.handle('versions', async () => {
  try {
    const r = await fetch('https://piston-meta.mojang.com/mc/game/version_manifest_v2.json');
    const j = await r.json();
    return { ok: true, latest: j.latest, versions: j.versions.map(v => ({ id: v.id, type: v.type })) };
  } catch (e) {
    return { ok: false };
  }
});
