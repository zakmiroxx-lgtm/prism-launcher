const { app, BrowserWindow, ipcMain, dialog, shell } = require('electron');
const fs = require('fs');
const path = require('path');
const { Client, Authenticator } = require('minecraft-launcher-core');

let win;
function createWindow() {
  win = new BrowserWindow({
    width: 1100, height: 680, minWidth: 820, minHeight: 560,
    backgroundColor: '#05060d', autoHideMenuBar: true, title: 'Prism Launcher', icon: path.join(__dirname, 'build', 'icon.png'),
    webPreferences: { preload: path.join(__dirname, 'preload.js') }
  });
  win.loadFile(path.join(__dirname, 'renderer', 'index.html'));
}
app.whenReady().then(createWindow);
app.on('window-all-closed', () => app.quit());

const gameRoot = () => path.join(app.getPath('userData'), 'game');
const instDir = o => path.join(gameRoot(), 'instances',
  `${o.version || 'x'}-${o.loader || 'vanilla'}`.replace(/[^\w.\-]/g, '_'));
const modsDir = o => { const d = path.join(instDir(o), 'mods'); fs.mkdirSync(d, { recursive: true }); return d; };

const UA = { 'User-Agent': 'PrismLauncher/0.1 (personal project)' };
async function getJson(url) {
  const r = await fetch(url, { headers: UA });
  if (!r.ok) throw new Error('HTTP ' + r.status + ' ' + url);
  return r.json();
}

// Fabric: скачиваем профиль загрузчика и кладём в versions/
async function ensureFabric(root, mc) {
  const list = await getJson(`https://meta.fabricmc.net/v2/versions/loader/${encodeURIComponent(mc)}`);
  if (!list.length) throw new Error('Fabric не поддерживает версию ' + mc);
  const entry = list.find(x => x.loader.stable) || list[0];
  const prof = await getJson(`https://meta.fabricmc.net/v2/versions/loader/${encodeURIComponent(mc)}/${encodeURIComponent(entry.loader.version)}/profile/json`);
  const dir = path.join(root, 'versions', prof.id);
  fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(path.join(dir, prof.id + '.json'), JSON.stringify(prof));
  return prof.id;
}

const send = (ch, data) => win && !win.isDestroyed() && win.webContents.send(ch, data);

ipcMain.handle('launch', async (_e, opts) => {
  const launcher = new Client();
  const root = path.join(app.getPath('userData'), 'game');
  const name = (opts.username || 'Player').replace(/[^\w]/g, '').slice(0, 16) || 'Player';
  const mem = Math.max(1, Math.min(32, Number(opts.ram) || 4));

  launcher.on('progress', p => send('progress', { type: p.type, task: p.task, total: p.total }));
  launcher.on('debug', m => send('log', String(m)));
  launcher.on('data', m => send('log', String(m)));
  launcher.on('close', code => send('closed', code));

  try {
    const version = { number: opts.version || '1.20.4', type: opts.vtype || 'release' };
    if (opts.loader && opts.loader !== 'vanilla') {
      version.custom = await ensureLoader(root, version.number, opts.loader);
    }
    const gameDirectory = instDir(opts);
    fs.mkdirSync(gameDirectory, { recursive: true });
    modsDir(opts);
    await launcher.launch({
      authorization: Authenticator.getAuth(name), // офлайн-режим
      root,
      version,
      memory: { max: `${mem}G`, min: '1G' },
      overrides: { gameDirectory }
    });
    return { ok: true };
  } catch (err) {
    return { ok: false, error: String(err && err.message || err) };
  }
});

// Список всех версий берётся с серверов Mojang при каждом запуске
ipcMain.handle('versions', async () => {
  try {
    const r = await fetch('https://piston-meta.mojang.com/mc/game/version_manifest_v2.json');
    const j = await r.json();
    return { ok: true, latest: j.latest, versions: j.versions.map(v => ({ id: v.id, type: v.type })) };
  } catch (e) {
    return { ok: false };
  }
});

// ---------- Моды ----------
const jarList = o => fs.readdirSync(modsDir(o)).filter(f => /\.jar(\.disabled)?$/i.test(f)).sort();

ipcMain.handle('mods:list', (_e, o) => jarList(o));

ipcMain.handle('mods:open', async (_e, o) => { await shell.openPath(modsDir(o)); return true; });

ipcMain.handle('mods:add', async (_e, o) => {
  const r = await dialog.showOpenDialog(win, {
    title: 'Выберите моды (.jar)', properties: ['openFile', 'multiSelections'],
    filters: [{ name: 'Моды Minecraft', extensions: ['jar'] }]
  });
  if (r.canceled) return jarList(o);
  const dir = modsDir(o);
  for (const f of r.filePaths) fs.copyFileSync(f, path.join(dir, path.basename(f)));
  return jarList(o);
});

ipcMain.handle('mods:remove', (_e, o, file) => {
  const safe = path.basename(file);
  const p = path.join(modsDir(o), safe);
  if (fs.existsSync(p)) fs.unlinkSync(p);
  return jarList(o);
});

ipcMain.handle('mods:toggle', (_e, o, file) => {
  const dir = modsDir(o), safe = path.basename(file);
  const from = path.join(dir, safe);
  const to = safe.endsWith('.disabled') ? path.join(dir, safe.slice(0, -9)) : path.join(dir, safe + '.disabled');
  if (fs.existsSync(from)) fs.renameSync(from, to);
  return jarList(o);
});

// Fabric API нужен почти всем Fabric-модам: берём с Modrinth
ipcMain.handle('mods:fabricApi', async (_e, o) => {
  try {
    const q = `https://api.modrinth.com/v2/project/fabric-api/version?game_versions=${encodeURIComponent(JSON.stringify([o.version]))}&loaders=${encodeURIComponent(JSON.stringify(['fabric']))}`;
    const vers = await getJson(q);
    if (!vers.length) return { ok: false, error: 'Fabric API для ' + o.version + ' не найден' };
    const file = vers[0].files.find(f => f.primary) || vers[0].files[0];
    const res = await fetch(file.url, { headers: UA });
    if (!res.ok) throw new Error('HTTP ' + res.status);
    fs.writeFileSync(path.join(modsDir(o), path.basename(file.filename)), Buffer.from(await res.arrayBuffer()));
    return { ok: true, mods: jarList(o) };
  } catch (e) {
    return { ok: false, error: String(e && e.message || e) };
  }
});

// ---------- Установка загрузчиков: Fabric / Forge / NeoForge ----------
const { spawn } = require('child_process');
const MANIFEST = 'https://piston-meta.mojang.com/mc/game/version_manifest_v2.json';

async function download(url, dest) {
  const r = await fetch(url, { headers: UA });
  if (!r.ok) throw new Error('HTTP ' + r.status + ' ' + url);
  fs.mkdirSync(path.dirname(dest), { recursive: true });
  fs.writeFileSync(dest, Buffer.from(await r.arrayBuffer()));
}

// Установщики Forge/NeoForge требуют готовую ванильную версию в versions/<mc>/
async function ensureVanilla(root, mc) {
  const dir = path.join(root, 'versions', mc);
  const jsonP = path.join(dir, mc + '.json'), jarP = path.join(dir, mc + '.jar');
  if (fs.existsSync(jsonP) && fs.existsSync(jarP)) return;
  send('status', 'Загрузка Minecraft ' + mc + '…');
  const man = await getJson(MANIFEST);
  const e = man.versions.find(v => v.id === mc);
  if (!e) throw new Error('Версия ' + mc + ' не найдена в списке Mojang');
  const j = await getJson(e.url);
  fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(jsonP, JSON.stringify(j));
  await download(j.downloads.client.url, jarP);
}

function neoPrefix(mc) {
  const p = mc.split('.');
  if (p[0] === '1') {
    if (p.length === 2) return p[1] + '.0.';          // 1.21   -> 21.0.
    if (p.length >= 3) return p[1] + '.' + p[2] + '.'; // 1.21.1 -> 21.1.
  } else if (Number(p[0]) >= 26) {
    if (p.length === 2) return p[0] + '.' + p[1] + '.0.'; // 26.3   -> 26.3.0.
    if (p.length >= 3) return p[0] + '.' + p[1] + '.' + p[2] + '.'; // 26.1.2 -> 26.1.2.
  }
  return null;
}

async function resolveLoader(loader, mc) {
  if (loader === 'forge') {
    const pr = await getJson('https://files.minecraftforge.net/net/minecraftforge/forge/promotions_slim.json');
    const v = pr.promos[mc + '-recommended'] || pr.promos[mc + '-latest'];
    if (!v) throw new Error('Для Minecraft ' + mc + ' нет Forge');
    return { version: v, url: `https://maven.minecraftforge.net/net/minecraftforge/forge/${mc}-${v}/forge-${mc}-${v}-installer.jar` };
  }
  const prefix = neoPrefix(mc);
  if (!prefix) throw new Error('NeoForge не поддерживает версию ' + mc + ' (для 1.20.1 используйте Forge)');
  const all = (await getJson('https://maven.neoforged.net/api/maven/versions/releases/net/neoforged/neoforge')).versions
    .filter(v => v.startsWith(prefix));
  const stable = all.filter(v => !/alpha|beta|snapshot/i.test(v));
  const v = (stable.length ? stable : all).pop();
  if (!v) throw new Error('Для Minecraft ' + mc + ' нет NeoForge');
  return { version: v, url: `https://maven.neoforged.net/releases/net/neoforged/neoforge/${v}/neoforge-${v}-installer.jar` };
}

function runInstaller(installer, root) {
  return new Promise((resolve, reject) => {
    const p = spawn('java', ['-jar', installer, '--installClient', root], { cwd: root, windowsHide: true });
    let tail = '';
    const onData = d => { const s = String(d); tail = (tail + s).slice(-1500); send('log', s); };
    p.stdout.on('data', onData); p.stderr.on('data', onData);
    p.on('error', e => reject(new Error('Не удалось запустить Java: ' + e.message)));
    p.on('close', code => code === 0 ? resolve() : reject(new Error('Установщик завершился с кодом ' + code + '\n' + tail.split('\n').slice(-6).join('\n'))));
  });
}

async function ensureLoader(root, mc, loader) {
  if (loader === 'fabric') {
    send('status', 'Установка Fabric…');
    return ensureFabric(root, mc);
  }
  fs.mkdirSync(root, { recursive: true });
  const mapP = path.join(root, 'prism-loaders.json');
  let map = {};
  try { map = JSON.parse(fs.readFileSync(mapP, 'utf-8')); } catch (e) {}
  const key = loader + ':' + mc;
  if (map[key] && fs.existsSync(path.join(root, 'versions', map[key], map[key] + '.json'))) return map[key];

  send('status', 'Поиск ' + loader + ' для ' + mc + '…');
  const info = await resolveLoader(loader, mc);
  await ensureVanilla(root, mc);
  const profiles = path.join(root, 'launcher_profiles.json');
  if (!fs.existsSync(profiles)) fs.writeFileSync(profiles, '{"profiles":{}}');

  const installer = path.join(root, 'installers', path.basename(info.url));
  send('status', 'Скачиваю установщик ' + loader + ' ' + info.version + '…');
  await download(info.url, installer);

  const vdir = path.join(root, 'versions');
  const before = new Set(fs.readdirSync(vdir));
  send('status', 'Устанавливаю ' + loader + ' (это может занять пару минут)…');
  await runInstaller(installer, root);
  const created = fs.readdirSync(vdir).filter(d => !before.has(d) && /forge/i.test(d));
  const id = created[0] || (loader === 'neoforge' ? 'neoforge-' + info.version : null);
  if (!id || !fs.existsSync(path.join(vdir, id, id + '.json'))) throw new Error('Установщик отработал, но профиль ' + loader + ' не создан');
  map[key] = id;
  fs.writeFileSync(mapP, JSON.stringify(map));
  return id;
}
