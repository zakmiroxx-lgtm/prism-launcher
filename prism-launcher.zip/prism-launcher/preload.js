const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('prism', {
  launch: opts => ipcRenderer.invoke('launch', opts),
  versions: () => ipcRenderer.invoke('versions'),
  on: (ch, fn) => ipcRenderer.on(ch, (_e, d) => fn(d))
});
