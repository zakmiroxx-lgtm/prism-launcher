const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('prism', {
  launch: opts => ipcRenderer.invoke('launch', opts),
  versions: () => ipcRenderer.invoke('versions'),
  mods: {
    list: o => ipcRenderer.invoke('mods:list', o),
    open: o => ipcRenderer.invoke('mods:open', o),
    add: o => ipcRenderer.invoke('mods:add', o),
    remove: (o, f) => ipcRenderer.invoke('mods:remove', o, f),
    toggle: (o, f) => ipcRenderer.invoke('mods:toggle', o, f),
    fabricApi: o => ipcRenderer.invoke('mods:fabricApi', o)
  },
  on: (ch, fn) => ipcRenderer.on(ch, (_e, d) => fn(d))
});
