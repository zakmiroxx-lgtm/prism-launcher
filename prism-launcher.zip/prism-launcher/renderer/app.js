// ---------- Шейдерный фон ----------
const canvas = document.getElementById('bg');
const gl = canvas.getContext('webgl');

const VERT = `attribute vec2 p; void main(){ gl_Position = vec4(p,0.,1.); }`;
const FRAG = `
precision highp float;
uniform vec2 u_res; uniform float u_time; uniform vec2 u_mouse; uniform float u_mode; uniform float u_int;

float hash(vec2 p){ p=fract(p*vec2(123.34,456.21)); p+=dot(p,p+45.32); return fract(p.x*p.y); }
float noise(vec2 p){
  vec2 i=floor(p), f=fract(p); f=f*f*(3.-2.*f);
  return mix(mix(hash(i),hash(i+vec2(1,0)),f.x), mix(hash(i+vec2(0,1)),hash(i+vec2(1,1)),f.x), f.y);
}
float fbm(vec2 p){ float v=0., a=.5; for(int i=0;i<5;i++){ v+=a*noise(p); p=p*2.02+vec2(17.,3.); a*=.5; } return v; }

vec3 aurora(vec2 uv, float t){
  vec3 col = mix(vec3(.01,.02,.06), vec3(.02,.05,.12), uv.y*.5+.5);
  vec2 s = floor(uv*90.); float star = step(.997, hash(s)) * (.5+.5*sin(t*2.+hash(s)*20.));
  col += star*.8;
  for(int i=0;i<4;i++){
    float fi=float(i);
    float w = fbm(vec2(uv.x*1.3 + t*.04*(fi+1.), t*.08 + fi*3.));
    float y = -.15 + fi*.14 + (w-.5)*.9;
    float d = uv.y - y;
    float band = exp(-d*d*38.) * smoothstep(-.25, .5, d+.2);
    float streak = .6 + .4*noise(vec2(uv.x*40., t*.6+fi));
    vec3 c = mix(vec3(.15,1.,.6), vec3(.55,.35,1.), clamp(fi/3.+w*.4,0.,1.));
    col += c * band * streak * .55;
  }
  return col;
}

vec3 nebula(vec2 uv, float t){
  vec2 q = vec2(fbm(uv*1.6 + t*.03), fbm(uv*1.6 + vec2(5.2,1.3) - t*.025));
  vec2 r = vec2(fbm(uv*1.6 + 3.*q + vec2(1.7,9.2) + t*.05), fbm(uv*1.6 + 3.*q + vec2(8.3,2.8) - t*.04));
  float f = fbm(uv*1.6 + 3.*r);
  vec3 col = mix(vec3(.03,.02,.10), vec3(.55,.12,.55), clamp(f*f*2.4,0.,1.));
  col = mix(col, vec3(.1,.55,.9), clamp(length(q)*.9,0.,1.)*.55);
  col = mix(col, vec3(1.,.75,.5), clamp(length(r.x)*f*1.2,0.,1.)*.35);
  vec2 s = floor(uv*120.); col += step(.996, hash(s))*.7;
  return col;
}

vec3 liquid(vec2 uv, float t){
  float v = 0.;
  for(int i=0;i<7;i++){
    float fi=float(i);
    vec2 c = vec2(sin(t*.31*(fi*.37+.8)+fi*2.1)*.75, cos(t*.27*(fi*.29+.9)+fi*1.7)*.45);
    v += .035 / (dot(uv-c, uv-c) + .002);
  }
  v = clamp(v*.18, 0., 3.);
  vec3 col = vec3(.02,.01,.07);
  col += vec3(.9,.25,.55) * smoothstep(.6, 1.0, v);
  col += vec3(.25,.55,1.) * smoothstep(.25, .75, v) * .55;
  col += vec3(1.,.9,.7) * smoothstep(1.6, 2.6, v) * .5;
  return col;
}

vec3 tunnel(vec2 uv, float t){
  float r = length(uv)+.0001, a = atan(uv.y, uv.x);
  float z = .35 / r;
  float rings = smoothstep(.45,.5, abs(fract(z*1.2 - t*.6) - .5));
  float rays = smoothstep(.40,.5, abs(fract(a*3.8197 + z*.35 + t*.1) - .5));
  float g = fbm(vec2(a*2., z*1.5 - t*.5));
  vec3 col = vec3(.02,.02,.08);
  col += mix(vec3(.2,.5,1.), vec3(1.,.3,.7), g) * rings * .8;
  col += vec3(.4,.2,.9) * rays * .35;
  col *= smoothstep(.0, .35, r);
  col += vec3(.7,.9,1.) * exp(-r*8.) * .6;
  return col;
}

void main(){
  vec2 uv = (gl_FragCoord.xy*2. - u_res) / min(u_res.x, u_res.y);
  vec2 m = (u_mouse*2. - 1.) * vec2(.12,.08);
  uv += m;
  float t = u_time;
  vec3 col;
  if(u_mode < .5) col = aurora(uv, t);
  else if(u_mode < 1.5) col = nebula(uv, t);
  else if(u_mode < 2.5) col = liquid(uv, t);
  else col = tunnel(uv, t);
  col *= u_int;
  col *= 1. - .35*dot(uv*.5, uv*.5);              // виньетка
  col += (hash(gl_FragCoord.xy + t) - .5) * .015;  // лёгкое зерно против бэндинга
  gl_FragColor = vec4(col, 1.);
}`;

function sh(type, src){
  const s = gl.createShader(type); gl.shaderSource(s, src); gl.compileShader(s);
  if(!gl.getShaderParameter(s, gl.COMPILE_STATUS)) console.error(gl.getShaderInfoLog(s));
  return s;
}
const prog = gl.createProgram();
gl.attachShader(prog, sh(gl.VERTEX_SHADER, VERT));
gl.attachShader(prog, sh(gl.FRAGMENT_SHADER, FRAG));
gl.linkProgram(prog); gl.useProgram(prog);

const buf = gl.createBuffer();
gl.bindBuffer(gl.ARRAY_BUFFER, buf);
gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1,-1, 1,-1, -1,1, 1,1]), gl.STATIC_DRAW);
const loc = gl.getAttribLocation(prog, 'p');
gl.enableVertexAttribArray(loc); gl.vertexAttribPointer(loc, 2, gl.FLOAT, false, 0, 0);

const U = n => gl.getUniformLocation(prog, n);
const uRes = U('u_res'), uTime = U('u_time'), uMouse = U('u_mouse'), uMode = U('u_mode'), uInt = U('u_int');

const SCALE = 0.7; // рендер в 70% разрешения для плавности
function resize(){
  canvas.width = Math.floor(innerWidth * SCALE);
  canvas.height = Math.floor(innerHeight * SCALE);
  gl.viewport(0, 0, canvas.width, canvas.height);
}
addEventListener('resize', resize); resize();

let mode = 0, intensity = 1, mx = .5, my = .5, smx = .5, smy = .5;
addEventListener('mousemove', e => { mx = e.clientX / innerWidth; my = 1 - e.clientY / innerHeight; });
const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;

const t0 = performance.now();
function frame(now){
  smx += (mx - smx) * .05; smy += (my - smy) * .05;
  const t = reduce ? 5 : (now - t0) / 1000;
  gl.uniform2f(uRes, canvas.width, canvas.height);
  gl.uniform1f(uTime, t);
  gl.uniform2f(uMouse, smx, smy);
  gl.uniform1f(uMode, mode);
  gl.uniform1f(uInt, intensity);
  gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
  requestAnimationFrame(frame);
}
requestAnimationFrame(frame);

// ---------- Интерфейс ----------
const $ = id => document.getElementById(id);
const save = () => localStorage.setItem('prism', JSON.stringify({
  user: $('user').value, ver: $('ver').value, ram: $('ram').value, mode, int: $('int').value
}));
let savedVer = null;
try {
  const s = JSON.parse(localStorage.getItem('prism') || '{}');
  if (s.user) $('user').value = s.user;
  savedVer = s.ver || null;
  if (s.ram) $('ram').value = s.ram;
  if (s.int) $('int').value = s.int;
  if (s.mode != null) mode = Number(s.mode);
} catch (e) {}
$('ramv').textContent = $('ram').value;
intensity = $('int').value / 100;
document.querySelectorAll('#modes button').forEach(b =>
  b.classList.toggle('on', Number(b.dataset.m) === mode));

document.querySelectorAll('#modes button').forEach(b => b.onclick = () => {
  mode = Number(b.dataset.m);
  document.querySelectorAll('#modes button').forEach(x => x.classList.toggle('on', x === b));
  save();
});
$('int').oninput = e => { intensity = e.target.value / 100; save(); };
$('ram').oninput = e => { $('ramv').textContent = e.target.value; save(); };
$('user').onchange = save;

const status = t => $('status').textContent = t;
window.prism.on('progress', p => {
  if (p.total) $('fill').style.width = Math.min(100, (p.task / p.total) * 100) + '%';
  status(`Загрузка: ${p.type} (${p.task}/${p.total})`);
});
window.prism.on('log', m => { if (/Launching|Started|Launch/i.test(m)) status('Игра запускается…'); });
window.prism.on('closed', code => {
  $('play').disabled = false; $('fill').style.width = '0';
  status(code === 0 ? 'Игра закрыта' : `Игра завершилась с кодом ${code}`);
});

$('play').onclick = async () => {
  save();
  $('play').disabled = true; $('fill').style.width = '0';
  status('Подготовка…');
  const opt = $('ver').selectedOptions[0];
  const r = await window.prism.launch({ username: $('user').value, version: $('ver').value, vtype: opt ? opt.dataset.type : 'release', ram: $('ram').value });
  if (!r.ok) {
    $('play').disabled = false;
    status('Ошибка: ' + r.error + ' (проверьте, что установлена Java)');
  }
};

// ---------- Первоапрельские версии ----------
// ID совпадают с теми, что Mojang держит в своём списке версий.
// В список попадают только те, что реально есть в манифесте.
const APRIL = [
  { id: '15w14a', year: 2015, name: 'The Love and Hugs Update' },
  { id: '1.RV-Pre1', year: 2016, name: 'The Trendy Update' },
  { id: '3D Shareware v1.34', year: 2019, name: '3D Shareware' },
  { id: '20w14infinite', year: 2020, name: '20w14\u221E (бесконечные измерения)' },
  { id: '22w13oneblockatatime', year: 2022, name: 'One Block at a Time' },
  { id: '23w13a_or_b', year: 2023, name: 'Vote Update (a или b)' },
  { id: '24w14potato', year: 2024, name: 'Poisonous Potato Update' },
  { id: '25w14craftmine', year: 2025, name: 'Craftmine' },
  { id: '26w14a', year: 2026, name: 'Herdcraft Update' }
];

function fillApril(manifestIds) {
  const set = new Set(manifestIds.map(x => x.toLowerCase()));
  const sel = $('apr');
  sel.innerHTML = '<option value="">не выбрано</option>';
  let found = 0;
  for (const v of APRIL.slice().reverse()) { // новые сверху
    if (!set.has(v.id.toLowerCase())) continue;
    const real = manifestIds.find(x => x.toLowerCase() === v.id.toLowerCase());
    const o = document.createElement('option');
    o.value = real; o.textContent = v.year + ': ' + v.name;
    sel.appendChild(o); found++;
  }
  return found;
}

// ---------- Список версий ----------
let allVersions = [], firstRender = true, latestRelease = null;
const FALLBACK = ['1.21.1','1.20.4','1.20.1','1.19.4','1.18.2','1.16.5'].map(id => ({ id, type: 'release' }));

function renderVersions() {
  const want = {
    release: $('f-release').checked,
    snapshot: $('f-snapshot').checked,
    old_beta: $('f-old').checked,
    old_alpha: $('f-old').checked
  };
  const prev = firstRender ? savedVer : $('ver').value;
  const sel = $('ver');
  sel.innerHTML = '';
  for (const v of allVersions) {
    if (!want[v.type]) continue;
    const o = document.createElement('option');
    o.value = v.id; o.dataset.type = v.type;
    o.textContent = v.type === 'snapshot' ? v.id + ' (снапшот)' : v.id;
    sel.appendChild(o);
  }
  const ids = [...sel.options].map(o => o.value);
  if (ids.includes(prev)) sel.value = prev;
  else if (ids.includes(latestRelease)) sel.value = latestRelease;
  firstRender = false;
  const apr = $('apr').value;
  if (apr) selectVersion(apr, 'snapshot');
}

function selectVersion(id, type) {
  const sel = $('ver');
  let o = [...sel.options].find(x => x.value === id);
  if (!o) {
    o = document.createElement('option');
    o.value = id; o.dataset.type = type; o.textContent = id + ' (снапшот)';
    sel.insertBefore(o, sel.firstChild);
  }
  sel.value = id;
}
['f-release', 'f-snapshot', 'f-old'].forEach(id => $(id).onchange = renderVersions);
$('ver').onchange = () => {
  if ($('apr').value && $('apr').value !== $('ver').value) $('apr').value = '';
  save();
};
$('apr').onchange = () => {
  const id = $('apr').value;
  if (id) selectVersion(id, 'snapshot');
  save();
};

(async () => {
  const r = await window.prism.versions();
  if (r && r.ok) {
    allVersions = r.versions; // Mojang отдаёт от новых к старым
    latestRelease = r.latest && r.latest.release;
    const n = fillApril(r.versions.map(v => v.id));
    status('Версий: ' + r.versions.length + ', первоапрельских: ' + n);
  } else {
    allVersions = FALLBACK;
    fillApril([]);
    status('Нет интернета: показан короткий список версий');
  }
  renderVersions();
})();
